#!/usr/bin/env bash

java -cp classes/:lib/* com.gradescope.sort.tests.RunTests
